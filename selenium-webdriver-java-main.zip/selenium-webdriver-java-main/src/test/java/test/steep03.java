package test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//3. In the list of all mobile , read the cost of Sony Xperia mobile (which is $100)
public class steep03 {

    private WebDriver driver;



    @Before
    public void setUp(){
        System.setProperty("webdriver.chrome.driver","chromedriver");
        driver = new ChromeDriver();
        driver.navigate().to("http://live.techpanda.org/index.php/mobile/sony-xperia.html");

    }

    @Test
    public void steep03 () {
        WebElement search = driver.findElement(By.id("price selectorgadget_selected"));
        search.sendKeys("Sony Xperia mobile (which is $100)");

        WebElement searchBnt = driver.findElement(By.xpath("//button[contains(text(),'SEARCH')]"));
        searchBnt.click();

        WebElement result = driver.findElement(By.xpath("//a[contains(text(),'[$100.00)]"));

        Assert.assertEquals("[.price.$1000",result.getText());
        //https://selenium-python.readthedocs.io/locating-elements.html
    }
    @After
    public void tearDown() {
        driver.close();
        driver.quit();
    }

}