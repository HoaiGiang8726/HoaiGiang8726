package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;

public class steep06 {
    private WebDriver driver;

    public steep06(WebDriver driver) {
        this.driver = driver;
    }

    public void searchGoogle() {
        driver.findElement(By.xpath("//*[@id='buy-now-button']")).click();
    }

    private static Object WebDriverManager;

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();

        driver.get("http://live.techpanda.org/index.php/mobile.html");

        Thread.sleep(3000);

        WebElement element = driver.findElement(By.xpath("100']"));
        Actions act = new Actions(driver);

        act.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();
        Thread.sleep(3000);

        ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
        driver.switchTo().window(tabs2.get(1));
        System.out.println(driver.getTitle());

    }
}


