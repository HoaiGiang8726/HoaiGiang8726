package test ;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
//2. Click on �MOBILE� menu
public class steep02 extends steep01 {

    @Test(description = "Verify page title")
    public void testPageTile() {

        String pageTitle = steep02.getPageTitle();
        assertEquals(pageTitle, "AUTOMATENOW – A place for learning software automated testing.", "The page title did not match!");
    }

    private static String getPageTitle() {
        return null;
    }

    @Test(description = "Verify welcome message")
    public void testGreeting() {

        String greeting = steep02.getWelcomeMessage();
        assertTrue(greeting.contains("Welcome"), "Welcome message did not match");
    }

    private static String getWelcomeMessage() {
        return null;
    }

    @Test(description = "Tests selecting a submenu")
    public void testSelectSubmenu() {

        steep02.selectIntroToSeleniumWebDriver();
    }

    private static void selectIntroToSeleniumWebDriver() {
    }
}