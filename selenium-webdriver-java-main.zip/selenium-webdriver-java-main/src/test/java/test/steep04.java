package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import java.util.concurrent.TimeUnit;
//4. Click on Sony Xperia mobile
public class steep04
{
    public static void main(String[] args)
    {
        WebDriver driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get(" http://live.techpanda.org/");
        WebElement link = driver.findElement(By.className("_menu"));
        Actions actions=new Actions(driver);
        actions.contextClick(link).perform();
        actions.sendKeys("Sony Xperia mobile").perform();
    }
}