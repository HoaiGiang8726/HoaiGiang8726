package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
// Read the Sony Xperia mobile from detail page
public class steep05 {
    private WebDriver driver;

    //Page URL
    private static String PAGE_URL=" http://live.techpanda.org/";

    //Locators

    //Apply as Developer Button
    @FindBy(how = How.LINK_TEXT, using = "APPLY AS A DEVELOPER")
    private WebElement developerApplyButton;

    //Constructor
    public steep05(WebDriver driver){
        this.driver=driver;
        driver.get(PAGE_URL);
        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    public void clickOnDeveloperApplyButton(){

        developerApplyButton.click();

    }
}