package TestBitits;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import static TestBitits.testcase6.driverFactory;
/* The next scenario is “Verify you can create account in E-commerce site and can share wishlist to other people using email”

        Detailed Test Case is below

/* Verify can create an account in e-Commerce site and can share wishlist to other poeple using email.
Test Steps:
1. Go to https://bitis.com.vn/account/login
2. Click on my account link
3. Click Create an Account link and fill New User information except Email ID
4. Click Register
5. Verify Registration is done. Expected account registration done.
6. Go to TV menu
7. Add product in your wish list - use product - LG LCD
8. Click SHARE WISHLIST
9. In next page enter Email and a message and click SHARE WISHLIST
10.Check wishlist is shared. Expected wishlist shared successfully.
*/
@Test
public class testcase7 {
    //step1

    public static void testLeftClickHandle() {
        //1. Init web-driver session
        WebDriver driver = driverFactory.getChromeDriver();
        try {
            //step1
            driver.get("https://bitis.com.vn/account/login");
            //dấu x
            By buttonClickPlace = new By.ByXPath("//*[@id='notifyCoupon']");
            WebElement buttonClickPlaceElem = driver.findElement(buttonClickPlace);
            buttonClickPlaceElem.click();

            //email
            By email= new By.ByXPath("//div[1]/form[1]/div[1]/input[1]");
            WebElement emailEle = driver.findElement(email);
            emailEle.sendKeys("giangtram4444@gmail.com");
//            Thread.sleep(2000);
            //pass
            By pass= new By.ByXPath("//div[1]/form[1]/div[2]/input[1]");
            WebElement passEle = driver.findElement(pass);
            passEle.sendKeys("Tramkute4444");
//            Thread.sleep(2000);

            By rightClickPlace = new By.ByXPath("//form[1]/div[3]/input[1]");

            WebElement rightClickPlaceElem = driver.findElement(rightClickPlace);
            rightClickPlaceElem.click();

        } catch (Exception e) {
            e.printStackTrace();
        }

//        //7. Quit browser session
//        driver.quit();
    }

}

