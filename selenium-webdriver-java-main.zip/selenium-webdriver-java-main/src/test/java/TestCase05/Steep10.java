package TestCase05;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.TimeUnit;

public class Steep10 {
    public static void main(String[] args)
    {
        WebDriver driver=new FirefoxDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("http://live.techpanda.org/index.php/wishlist/");
        WebElement link = driver.findElement(By.className("_menu"));
        Actions actions=new Actions(driver);
        actions.contextClick(link).perform();
        actions.sendKeys("Wishlist").perform();
    }
}
