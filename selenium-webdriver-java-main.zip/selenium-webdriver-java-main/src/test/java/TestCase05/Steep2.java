package TestCase05;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
public class Steep2 {
    @Test
    public void login() {
        WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://live.techpanda.org/index.php/customer/account/login/");
        WebElement username=driver.findElement(By.id("user_email_Login"));
        WebElement password=driver.findElement(By.id("user_password"));
        WebElement login=driver.findElement(By.name("commit"));
        username.sendKeys("abc@gmail.com");
        password.sendKeys("your_password");
        login.click();
        String actualUrl=" http://live.techpanda.org/";
        String expectedUrl= driver.getCurrentUrl();
        Assert.assertEquals(expectedUrl,actualUrl);
    }
}
