package TestCase05;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
@Test
public class Steep7 {
private Iterable<? extends WebElement> productWebElements;

    public Steep7(Iterable<? extends WebElement> productWebElements) {
        this.productWebElements = productWebElements;
    }

    public List<String> getAllProductsInTrolley() {
            WebDriver driver=new ChromeDriver();
            List<String> actualList = new ArrayList<>();
           driver.get("http://live.techpanda.org/index.php/checkout/cart/");
            for (WebElement product : productWebElements) {
                String productName = product.getText();
                if (!productName.isEmpty()) {
                    actualList.add(productName);
                    System.out.println("Product :" + productName);
                }
            }
            return actualList;
        }
    }
