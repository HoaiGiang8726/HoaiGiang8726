package TestCase05;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class Steep6{
    @Test
    public static void main(String[] args) {
        WebDriver driver = new FirefoxDriver();
        //implicit wait
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //URL launch
        driver.get("http://live.techpanda.org/index.php/tv.html");
        //identify menu
        //WebElement n=driver.findElement(By.id("nav-link-accountList"));
        // object of Actions with method moveToElement
        Actions a = new Actions(driver);
      //  a.moveToElement(n).perform();
        //identify sub-menu element
        WebElement m=driver.
                findElement(By.xpath("//*[text()='Create a List']"));
        //move to element and click
        a.moveToElement(m).click().perform();
        System.out.println("Page navigated to: " +driver.getTitle());
        driver.quit();
    }
}