package TestCase05;

import org.junit.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.openqa.selenium.remote.DriverCommand.STATUS;
import static sun.security.x509.PolicyInformation.ID;

public class Steep5 {
   // private static final String REGNO = ;
    private Object DatabaseConnector;

    @Test
    public void testVerifyListOfRecords() throws InterruptedException {

       // String query = "SELECT ID FROM usermaster WHERE RegistrationNumber = '" + REGNO + "' ";
       // String ID = DatabaseConnector.executeSQLQuery("QA", query);


        String sqlQuery = "SELECT FirstName,LastName,SpecialityCode,QualificationCode FROM usermaster WHERE ID = '" + ID + "' ";
        List<String> listOfDBValues = new ArrayList<String>();
       // listOfDBValues = DatabaseConnector.executeSQLQuery_List("QA", sqlQuery);
        List<String> Branch = new ArrayList<>();
        Branch.add(listOfDBValues.get(0));

        List<String> list1 = new ArrayList<>(Arrays.asList("testfirstname testlastname ORP DM"));
        Assert.assertEquals(STATUS, "TRUE");
        System.out.println("STATUS IS " + STATUS);
        Assert.assertEquals(Branch, list1);
    }
}