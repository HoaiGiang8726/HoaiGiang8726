package TestCase05;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Steep4  {
@Test
    public static void main(String[] args) throws Exception {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://live.techpanda.org/index.php/customer/account/create/");

        driver.findElement(By.name("email")).sendKeys("manhtquan01051@gmail.com");
        driver.findElement(By.name("password")).sendKeys("87268726");

        driver.findElement(By.xpath("/html/body/div[1]/section/form/div/div/button\r\n" +
                "")).click();

        Thread.sleep(2000);
        driver.findElement(By.xpath("/html/body/div[2]/header/aside/ul/li[2]/a")).click();

        Thread.sleep(2000);


        for (int i = 0; i < 75; i++) {

            driver.findElement(By.id("navbarDropdown")).click();

            Thread.sleep(1000);

        }
    }
}
