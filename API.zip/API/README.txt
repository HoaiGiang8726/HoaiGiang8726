start: npm run start
npm run start-auth