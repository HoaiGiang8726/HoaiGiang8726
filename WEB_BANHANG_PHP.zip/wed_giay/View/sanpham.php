  <!-- quảng cáo -->
  <?php
  include "quangcao.php";
  ?>
  <!-- end quảng cáo -->
  <!-- phân trang -->
  <?php
   //tìm tổng số hàng hóa 
   $hh= new HangHoa();
   $results=$hh->getListHangHoaAll();//trả về tất cả sp
   $count=$results->rowCount(); //đếm xem có tát cả bao nhiêu 
   //giới hạn mỗi trang bnhieu sp 
   $limit=8; // 1 trang 8sp
   ///tính phần tổng sô trang và start bên page.php
   $p=new Page();
   $page=$p->findPage($count,$limit);// 
   // tính start 
   $start=$p->findStart($limit);
   //tìm cuurent bpage dựa vào gết url
  $current_page=isset($_GET['page'])?$_GET['page']:1;
   //    
  ?>
  
  <!-- end số lượt xem san phẩm -->
  <!-- sản phẩm-->
 <?php
    if(isset($_GET["act"]))
    {
        if($_GET["act"]=="sanpham")
        {
            $ac=1;
        }
        elseif($_GET["act"]=="khuyenmai")
        {
            $ac=2;
        }
        elseif($_GET["act"]=="timkiem")//tìm kiếm rồi đổ về đây
        {
            $ac=3;
        }
        else{
            $ac=0;
        }
    }
 ?>

  <!--Section: Examples-->
  <section id="examples" class="text-center">

      <!-- Heading -->
      <div class="row">
          <div class="col-lg-8 text-right">
             <!-- tiêu đề -->
             <?php
             if($ac==1)// là sản phẩm
             {
                 echo ' <h3 class="mb-5 font-weight-bold">SẢN PHẨM</h3>';
             }
             elseif($ac==2)
             {
                 echo ' <h3 class="mb-5 font-weight-bold">SẢN PHẨM KHUYẾN MÃI</h3>';
             }
             elseif($ac==3)// là ra sp tk
             {
                echo ' <h3 class="mb-5 font-weight-bold">SẢN PHẨM tÌM kiếm</h3>';
            }
             ?>
            
          </div>

      </div>
      <!--Grid row-->
      <div class="row">
         <!-- CHI TIẾT NỘI DUNG -->
         <?php
            $hh=new HangHoa();
            if($ac==1)
            {
                $results=$hh->getListHangHoaAll();

            }
            elseif($ac==2)
            {
                $results=$hh->getListHangHoaSaleAll();
            }
            elseif($ac==3)// là ra sp tk
            {
                   // vì forrm là method post nên nó gửi dữ liệu tk 
                //qua đây
                if($_SERVER['REQUEST_METHOD']=='POST')
                {
                    // echo "có phải bạn ddrng tìm + $timkiem "   ;// ra cái j tìm 
                    //gửi qua đây là tên cần cần tk trên thẻ input name txtsearch
                    //nhận 
                    $timkiem=$_POST['txtsearch'];
                      echo "có phải bn đang tìm   $timkiem  ";
                    //viết truy vấn bên model
                }
                $results=$hh->getSearch($timkiem);
            }
            while($set=$results->fetch()):
         ?>
              <!--Grid column-->
              <div class="col-lg-3 col-md-4 mb-3 text-left">

                  <div class="view overlay z-depth-1-half">
                      <img src="<?php echo 'Content/imagetourdien/'.$set['hinh'];?>" class="img-fluid" alt="">
                      <div class="mask rgba-white-slight"></div>
                  </div>
                    <!-- tiền tệ -->
                    <?php
                    if($ac==2){
                        echo '<h5 class="my-4 font-weight-bold">
                        <font color="red">'.number_format($set['giamgia']).'<sup><u>đ</u></sup></font>
                        <strike>'.number_format($set['dongia']).'</strike><sup><u>đ</u></sup>
                        </h5>';
                    }
                    else{
                        echo '<h5 class="my-4 font-weight-bold" style="color: red;">'.number_format($set['dongia']).'<sup><u>đ</u></sup></br>';
                    }
                    ?>
                    
                  </h5>
                  <a href="index.php?action=home&act=detail&id=<?php echo $set['mahh'];?>">
                      <span><?php echo $set['tenhh'].'-'.$set['mausac'];?></span></br></a>
                  <button class="btn btn-danger" id="may4" value="lap 4">New</button>
                  <h5>Số lượt xem:<?php echo $set['soluotxem'];?></h5>

              </div>
        <?php
        endwhile;
        ?>
      </div>

      <!--Grid row-->

  </section>
 
  
  <!-- end sản phẩm mới nhất -->
  
 
  <div class="col-md-6 div col-md-offset-3">
				<ul class="pagination">
					   <?php
                       //hiển thị prevtrang sau
                       if($current_page>1 && $page>1)
                       {
                           echo '<li><a href="index.php?action=home&act=sanpham&page='.($current_page-1).'">prev</a></li>';
                       }
                         for ($i=1; $i<=$page ; $i++)
                         {
                          ?>
				    <li ><a href="index.php?action=home&act=sanpham&page=<?php  echo $i; ?>"><?php  echo $i; ?></a></li>

                       <?php
                         }
                         //hiển thị next 
                         if($current_page<$page && $page>1)
                         {
                             echo'<li><a href="index.php?action=home&act=sanpham&page='.($current_page+1).'"> next</a></li>';
                         }
                       ?>
				   
				</ul>
</div>