<!-- quảng cáo -->
<div class="container">
      <div class="row text-center">
          <div class="col-12">
              <h3 class="mb-5 font-weight-bold text-center" style="color: red;">PERSONA IN SUMMER FALL 2020</h3><br />
              <img src="Content/imagetourdien/8901595576957.gif" height="400px" alt="" />
          </div>
      </div>
  </div>
  <!-- end quảng cáo -->