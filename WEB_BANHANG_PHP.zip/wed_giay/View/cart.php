
<div class="table-responsive">
  <!-- kiểm tra xem giỏ hàn có hay ko  -->
  <?php
if(!isset($_SESSION['cart'])||count($_SESSION['cart'])==0):
  echo '<script> alert ("giỏ hàng chưa có gì ,tiếp tục mua hàng "); </script>';
 include "home.php";
  // echo '<meta http-equiv="refresh" content="0;url=./index.php?action=giohang&act=giohang"/>';  
  ?>
  <?php
else : 
  ?>
    <form action="index.php?action=giohang&act=update_cart" method="post">
      <table class="table table-bordered">
        <thead>
          <tr><td colspan="5"><h2 style="color: red;">THÔNG TIN GIỎ HÀNG</h2></td></tr>
          <tr class="table-success">
            <th>Số TT</th>
            <th>Thông Tin Sản Phẩm</th>
            <th>Tùy Chọn Của Bạn</th>
            <th colspan="2">Giá</th>
          </tr>
        </thead>
        <tbody>
          <!-- do sản phẩm người dùng mua đc lưu trong giở hnagf r, chúng ta phải dòng 
        vòng lặp for lấy sanrphaamr ra -->
        <?php
        $j=0 ;
         foreach ($_SESSION['cart'] as $key=>$item):
          $cost=number_format($item['cost'],0);
          $total=number_format($item['total'],0);
          $j++;
        ?>
            <tr>  
              <td><?php echo $j ;?></td>
              <td><img width="50px" height="50px" src="Content/imagetourdien/<?php echo $item['hinh'] ;?>" ><?php echo $item['name'] ; ?></td>
              <td><h7 style="color: red;">Màu : </h7><?php echo $item ['mau'] ;?> 
              <h7 style="color: red;"> Size : </h7> <?php echo $item ['size'] ;?> </td>
              <td>
              <h7 style="color: red;">
              Đơn Giá :</h7><?php echo $cost ;?> <sup><u>vnđ</u></sup>
              <h7 style="color: red;">- Số Lượng :</h7>
               <input type="number" name="newqty[<?php echo $item['mahh'] ?>]" value="<?php echo $item['qty'] ;?>" />
               <br />
               <p style="float: right;"> Thành Tiền :<h7 style="color: red;"> <?php echo $total ;?> </h7><sup><u>vnđ</u></sup></p>
              </td>
              <td>
                <a href="index.php?action=giohang&act=emty_cart&id=<?php echo $item['mahh'] ?>"><button type="button" class="btn btn-danger">Xóa </button></a>
                <button type="submit" class="btn btn-secondary">Sửa  </button>
              </td>
            </tr>
        <?php
        endforeach;
        ?>
          <tr>
            <td colspan="3">
              <b>Tổng Tiền Bạn phải thanh toán </b>
            </td>
            <td style="float: right;">
              <b> <?php echo get_subtotal(); ?> <sup><u>vnđ</u></sup></b>
            </td>
            <!--  nhấn nút thanh toán nó add vào daata base  -->
            <td><a href="index.php?action=order&act=order_detail">Thanh toán</a></td>
          </tr>
        </tbody>
      </table>
    </form>
    <?php
endif;
?>
</div>
</div>
