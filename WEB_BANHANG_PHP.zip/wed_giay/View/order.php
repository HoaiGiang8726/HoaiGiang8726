<div class="table-responsive">
 <!-- kiểm tr người dùng có đăng nhập hay chưa mới mua hàng đc -->
 <?php
 if(!isset($_SESSION['makh'])|| count($_SESSION['cart'])==0):
  echo '<script> alert("Bạn chưa đăng nhập");</script>';
  include "View/login.php";
 ?>
<!-- ngược lại họ đăng nhập rồi giỏ hàng có hàng thì hiển thị form ra -->
<?php
else:
?>
    <form action="" method="post">
      <table class="table table-bordered" border="0">
      <?php
       $hd=new HoaDon();
      if(isset($_SESSION['sohd']))
      {
        $result=$hd->getOrder($_SESSION['sohd']);
        // echo $result;
        // bởi vì trả về cho mình là 1 row
        $sohd= $result[0];
        $tenkh=$result[1];
        $ngaydat=$result[2];
        $diachi=$result[3];
        $sodt=$result[4];
        $date=new DateTime($ngaydat);
        $ngay=$date->format("d/m/Y");
      }
     
      ?>
                        
       <tr>
          <td colspan="4">
            <h2 style="color: red;">THANH TOÁN HÓA ĐƠN CỦA BẠN </h2>
          </td>
        </tr>
      <tr>
          <td colspan="2"><h7 style="color: red;">Số Hóa Đơn  : </h7><?php echo  $sohd;?></td>
          <td colspan="2"><h7 style="color: red;">Ngày Lập : </h7> <?php echo  $ngay;?></td>
        </tr>
       <tr>
          <td colspan="2"><h7 style="color: red;">Họ và Tên  : </h7></td>
          <td colspan="2"><?php echo  $tenkh;?></td>
        </tr>
       <tr>
          <td colspan="2"><h7 style="color: red;">Địa chỉ giao hàng :  </h7 ></td>
          <td colspan="2"><?php echo  $diachi;?></td>
        </tr>
        <tr>
          <td colspan="2"><h7 style="color: red;">Số điện thoại :  </h7 > </td>
          <td colspan="2"><?php echo  $sodt;?></td>
        </tr>
      </table>
      <!-- Thông tin sản phầm -->
      <table class="table table-bordered">
        <thead>
          <tr class="table-success">
            <th>Số TT</th>
            <th>Thông Tin Sản Phẩm</th>
            <th>Tùy Chọn Của Bạn</th>
            <th>Giá</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $j=0;
          $result=$hd->getOrderDetail($_SESSION['sohd']);
          // do trả về nhiều hang hóa
          while($set=$result->fetch()):
            $j++;
          ?>
            <tr>
              <td><?php echo $j;?></td>
              <td><h7 style="color: red;">Tên SP : </h7> <?php echo $set['tenhh'];?></td>
              <td ><h7 style="color: red;">Màu : </h7> <?php echo $set['mausac'];?><h7 style="color: red;">Size : </h7> <?php echo $set['size'];?> </td>
              <td><h7 style="color: red;">Đơn Giá : </h7> <?php echo $set['dongia'];?> <h7 style="color: red;">  Số Lượng  : </h7> <?php echo $set['soluongmua'];?> <br />
              </td>
            </tr>
            <?php
          endwhile;
          ?>
          <tr>
            <td colspan="3">
              <b style="color: blue;">Tổng Tiền</b>
            </td>
            <td style="float: right;">
              <b><?php echo get_subtotal();?> <sup><u>đ</u></sup></b>
            </td>
           
          </tr>
         
        </tbody>
      </table>
    </form>
<?php
endif;
?>
</div>
</div>