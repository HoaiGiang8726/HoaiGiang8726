<?php
$action="order";
if(isset($_GET['act']))
{
    $action=$_GET['act'];
}
switch($action)
{
    case "order":
        include "View/order.php";
        break;
    case "order_detail":
        // đầu tiên phải insert dc vào bảng hóa đơn vì có mã số hóa đơn trước thì mới 
        // insert vào bảng chi tiết hd
        // lấy được makh
        $hd=new HoaDon();//$_SESSION['makh']
        $sohdid=$hd->insertOrder($_SESSION['makh']);//26
        // tiến hàng lưu mã số hóa đơn vào trong session
        $_SESSION['sohd']=$sohdid;
        // sau khi có mã số hóa đơn thì tiến hàng lưu vào bảng chi tiết hóa hóa đơn
        $total=0;
        foreach($_SESSION['cart'] as $key=>$item)
        {
            $hd->insertOrderDetail($sohdid,$item['mahh'],$item['qty'],$item['mau'],$item['size'],$item['total']);
            $total+=$item['total'];
        }
        // sau khi chèn xong thì tiến hành update lại tổng tiền trong bảng hóa đơn
        $hd->updateOrderTotal($sohdid,$total);
        include 'View/order.php';
        break;
}
?>