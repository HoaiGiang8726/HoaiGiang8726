<?php
$action="registration";
if(isset($_GET['act']))
{
    $action=$_GET['act'];//registration_action
}
switch($action)
{
    case "registration":
        include 'View/registration.php';
        break;
    case "registration_action":
        // // nhận thông tin khi mà người dùng nhấn nút submit $_POST=array('txttenkh'='ly','txtdiachi'='hcm'...)
        $tenkh=$_POST['txttenkh'];//kien đc gán cho $tenkh
        $username=$_POST['txtusername'];//gans teen kien
        $password=$_POST['txtpass'];//123
        $crypt=md5($password);
        $email=$_POST['txtemail'];//hthk288@gmail.com
        $diachi=$_POST['txtdiachi'];//long an
        $dt=$_POST['txtsodt'];//123456
        // tất cả thông tin này muốn chèn vào databse thì phải để vào câu lệnh insert
        // insert into khachhang1 values(Null,'kien','hthk'...)
        // nhưng câu lệnh insert phải đc viết trong lớp model
        $u=new User();
        $u->InsertUser1($tenkh,$username,$crypt,$email,$diachi,$dt);
        echo '<script> alert("Đăng Ký Thành Công")</script>';
        // $dt->XuLyRes();
        include 'View/home.php';
        break;
        // nếu đăng ký thành công thì quay về trang home



}
?>