<?php 
$action="giohang";
if(!isset($_SESSION['cart']))
{
    $_SESSION['cart']=array();//giỏ hàng là array chứa nhiều sản phẩm ỏ đây 
}
if(isset($_GET['act']))
{
    $action=$_GET['act'];
}
switch($action) {
    case "giohang":
        include "View/cart.php";
        break;
        case "add_cart":
            //khi người dùng nhấn nút submit mua hàng bên sản phẩm chi tiết thì sẽ gửi hình ,tên sp ,màu ...
            // lưu vào $_POSt(),mà POST chhir nhận giá trị thông qua name
            $mahh=$_POST['mahh'];
            //hình ko chuyền qua đc ko có name 
            //tên cũng ko chuyền qua đc vì nó là thẻ h3 ko có name 
            $mausac=$_POST['mymausac'];
            $soluong=$_POST['soluong'];
            $size=$_POST['size'];
            //do lớp giỏ hang trong model ko phải class nên ko cần tạo đối tượng 
            add_item($mahh,$soluong,$mausac,$size) ;
            echo '<meta http-equiv="refresh" content="0;url=./index.php?action=giohang&act=giohang"/>';  
            break ;
           case "emty_cart":
            //nhận id giỏ hàng thực hiện xóa 
            if(isset($_GET['id']))
            {
                $key=$_GET['id'];
                //xóa unset
                unset($_SESSION['cart'][$key]);
                echo '<meta http-equiv="refresh" content="0;url=./index.php?action=giohang&act=giohang"/>';  
            }
            break ;
            case "update_cart":
                $soluongnew=$_POST['newqty'];
                //duyệt lại trong giỏ hàng 
                // vì số lượng là lưu mã sp , giả sử giỏ 2 mã 20,21
                // $soluongnew=$_POST['20=>1,...'];
                foreach($soluongnew as $key => $qty)
                {
                    if($_SESSION['cart'][$key]['qty'] != $qty)
                    {
                        update_item($key,$qty);
                    }
                }
                echo '<meta http-equiv="refresh" content="0;url=./index.php?action=giohang&act=giohang"/>';  
                break ;
}
?>