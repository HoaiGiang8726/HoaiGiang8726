<?php
$action="home";
// index làm việc với controller,controller điều hướng, yêu cầu view hiển thị
// cái gì, và điều hướng cả model
if(isset($_GET['act']))
{
    $action=$_GET['act'];//sanpham
}
switch($action){
    case "home":
        include 'View/home.php';
        break;
    case "sanpham":
        include 'View/sanpham.php';
        break;
    case "khuyenmai":
        include 'View/sanpham.php';
        break;
    case "detail":
        // gởi qua đây id mã sản phẩm nào đó
        include 'View/sanphamchitiet.php';
        break;
        case "comment":
            //tuyền qua đây mã hàng ,nội dụng comment 
            $makh=$_SESSION['makh'] ;
            $mahh=$_POST['txtmahh'];
            $noidung=$_POST['comment'];
            //viết câu insert để chèn vào database
            $u=new User();
            $u->insertComment($mahh,$makh,$noidung);
            include 'View/sanphamchitiet.php';
            break;
            case "timkiem" :
                include "View/sanpham.php";
                break;
}
?>