<?php
$action="login";
if(isset($_GET['act']))
{
    $action=$_GET['act'];
}
switch($action)
{
    case "login":
        include 'View/login.php';
        break;
    case "login_action":
        //truyền qua $_POST=array('txtusername'='sony','txtpassword'='123')
        $username=$_POST['txtusername'];
        $password=$_POST['txtpassword'];
        // nhưng mà pass lúc này là 123 ko giống với pass trong database(vì đã đc mã hóa)
        // vậy mã password đăng nhập ra để cùng kiểu với pass trong database
        $cypt=md5($password);
        $db=new User();
        $log=$db->login($username,$cypt);//$log[12,ngọc,sony,123,ngoc@gmail.com,longxuen,123456,0]
        // session để trao đổi dữ liệu từ trang này qua trang khác vid dụ: người dùng đăng nhập
        // thì thông tin đăng nhập được lưu lại và chuyển cho các trang khác 
        // session là thôn tin phiên làm việc của người dùng, trong PHP nó có thư mục php.ini:session.save.path
        // thông tin này nó sẽ đc dùng chung cho tất cả trang
        // Session hoạt động khi gọi hàm sesion_start(). nên gọi hàm này ngay khi bắt đầu trang
        if($log ==true)
        {
            $_SESSION['makh']=$log[0];
            $_SESSION['tenkh']=$log[1];
            $_SESSION['username']=$log[2];
            $_SESSION['matkhau']=$log[3];
            $_SESSION['email']=$log[4];
            $_SESSION['diachi']=$log[5];
            $_SESSION['sodt']=$log[6];
            echo '<script> alert("Đăng nhập thành công");</script>';
            // load lại trang trong thời gian là 0 giây(content=0), muốn 1 giay thì sửa 0 thành 1, sau đó điều hướng tới trang home
            echo '<meta http-equiv="refresh" content="0;url=./index.php?action=home&act=home"/>';  
            // include "View/home.php";
        }
        break;
    case "log_out":
        if(isset($_SESSION['makh'])&& isset($_SESSION['tenkh']))
        {
            // unset dùng để làm gì? là loại bỏ 1 phần tử trong mảng
            // hàm unset sẽ loại bỏ 1 hoặc nhiều biến được truyền vào. cũng có thể được sử dụng để loại bỏ một
            // phần tử xác định trong mảng
            // cú pháp: unset($var)
            // ví dụ: array=['php','angulajs','nodejs']=>unset($array[1])=>array=['php','nodejs']
            // lưu ý: nếu 1 biến toàn cục thì unset xóa trong 1 hàm đó, biến đó chỉ loại trong hàm đó thôi, để
            // xóa biến toàn cục trong hàm sử dụng mảng $GOBALS
            // ví dụ
            // function testA()
            //   unset($GLOBAL['test'])
            // $test='abc.com';
            // testA()=>
            //dùng unset để xóa đi mã khách hàng và tên kh
            unset($_SESSION['makh']);
            unset($_SESSION['tenkh']);
           
        }
        echo '<meta http-equiv="refresh" content="0;url=./index.php?action=home&act=home"/>';  
        break;
}
?>