<?php
class Page{
    //viết phương thức  vì thực hiện việc phân trang  starrt
    //muốn tìm đc start thì phải chuyeenf vào giới hạn limit và cuẻnt
    function findStart($limit)
    {
        if(!isset($_GET['page'])||($_GET['page']==1))
        {
            $start=0;
            $_GET['page']=1;//get page bằng trang số 1 
        }
        else {
            //người dùng chọn trang 23456
            $start=($_GET['page']-1)*$limit;
        }
        return $start ;
    }
    //tìm pt tính tổng số trang 
    function findPage($count,$limit)
    {//
        $page=(($count%$limit)==0)?$count/$limit:floor($count/$limit)+1;  //chia ra số chẵn 
    return $page;
    }
}
?>