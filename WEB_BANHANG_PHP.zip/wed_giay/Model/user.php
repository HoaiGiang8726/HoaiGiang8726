<?php
class User{
    // thuộc tính
    var $makh=0;
    var $tenkh=null;
    var $user=null;
    var $pass=null;
    var $email=null;
    var $diachi=null;
    var $sodt=null;
    var $vaitro=0;// vì vai trò trong database cho kiểu bit mà default 0
    // hàm tạo
    public function __construct(){}
    //phương thức của 1 bảng là những lệnh insert,select,update,delete
    // phương thức thêm dữ liệu vào bảng kháchhagn
   public function InsertUser($tenkh,$user,$matkhau,$email,$diachi,$dt)// ly,lychau,123,ly@gmail.com,hcm,123456
    {
        // câu lệnh truy vấn
        $query="insert into khachhang1(makh,tenkh,username,matkhau,email,diachi,sodienthoai,vaitro) values(Null,?,?,?,?,?,?,default)";
        // b2: prepare
        $db=new connect();
        $stm=$db->execP($query);
        // muốn preapre thì phải execute
        $stm->execute([$tenkh,$user,$matkhau,$email,$diachi,$dt]);//[ly,lychau,123,ly@gmai.com,hcm,123456]
    }
    // dùng giá trị ràng buộc
    public function InsertUser1($tenkh,$user,$matkhau,$email,$diachi,$dt)
    {
        // câu lệnh truy vấn
        $query="insert into khachhang1(makh,tenkh,username,matkhau,email,diachi,sodienthoai,vaitro) values(Null,:tenkh,:username,:matkhau,:email,:diachi,:sodienthoai,default)";
        // b2: prepare
        $db=new connect();
        $stm=$db->execP($query);
        // muốn preapre thì phải execute
        // dùng giá trị ràng buộc
        // $stm->bindValue(':tenkh',$tenkh);
        // $stm->bindValue(':username',$user);
        // $stm->bindValue(':matkhau',$matkhau);
        // $stm->bindValue(':email',$email);
        // $stm->bindValue(':diachi',$diachi);
        // $stm->bindValue(':sodienthoai',$dt);
        $stm->bindParam(':tenkh',$tenkh);
        $stm->bindParam(':username',$user);
        $stm->bindParam(':matkhau',$matkhau);
        $stm->bindParam(':email',$email);
        $stm->bindParam(':diachi',$diachi);
        $stm->bindParam(':sodienthoai',$dt);
        $stm->execute();
    }
    // cách tiêu chuẩn ko dùng prepare, câu truy vấn làm việc trực tiếp
    public function InsertUser2($tenkh,$user,$matkhau,$email,$diachi,$dt)
    {
        // câu lệnh truy vấn
        $query="insert into khachhang1(makh,tenkh,username,matkhau,email,diachi,sodienthoai,vaitro) values(Null,'$tenkh','$user','$matkhau','$email','$diachi','$dt',default)";
        // b2: exec
        $db=new connect();
        $stm=$db->exec($query);   
    }
    public function login($username, $password)
    {
        $select="select * from khachhang1 WHERE username='$username' and matkhau='$password'";
        $db=new connect();
        $result=$db->getList($select);
        // vì nó trả về đúng 1 user nên fetch đúng 1 dòng
        $set= $result->fetch();
        return $set;// $set[sony,123]
    }
   public function insertComment($mahh,$makh,$noidung)
   {
     
    $query="insert into binhluan1 (mabl,mahh,makh,ngaybl,noidung)values(NULL,:mahh,:makh,:ngaybl,:noidung)";
    $data=new DateTime("now");
    $ngay=$data->format("Y-m-d");
    $db=new connect();
    $stm=$db->execP($query);
    $stm->bindParam(':mahh',$mahh);
    $stm->bindParam(':makh',$makh);
    $stm->bindParam(':ngaybl',$ngay);
    $stm->bindParam(':noidung',$noidung);
    $stm->execute();
   }
   function displayComment($mahh)
   {
       $select ="select a.username,b.noidung from khachhang1 a INNER join binhluan1 b on a.makh=b.makh where mahh=$mahh  order by b.mabl desc ";
      
       $db=new connect();
       $result=$db->getList($select);
       return $result;
   }
   function getTotalComment($mahh)
   {
       $select="select count(makh) from binhluan1 where mahh=$mahh";
       $db=new connect();
       $result=$db->getInstance($select);
       return $result;

   }
   // phương thức trả về địa chỉ emial và mk
   function getEmail($email){
       $select="select email,matkhau from khachhang1 where email='$email'";
       $db=new connect();
       $result=$db->getInstance($select);
       return $result;
   }
   function getPassEmail($email, $pass)
   {
       $select ="select email,matkhau from khachhang1 where md5(email)='$email' and md5(matkhau)='$pass'";
       // select email, matkhau from khachhang1 where md5(phptestly20@gmail.com)='405999d3a4fb8cddf893e238928c001'
       $db=new connect();
       $result= $db->getInstance($select);
       return $result;
   }
   function updateEmail($emailold,$passnew){
    $db=new connect();
    $query=" update khachhang1 set matkhau='$passnew' where email='$emailold'";
    $db->exec($query);
   }
}
?>