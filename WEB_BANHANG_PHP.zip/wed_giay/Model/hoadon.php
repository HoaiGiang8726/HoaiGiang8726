<?php
class HoaDon{
    // khai báo thuộc tính
    var $sohd=null;
    var $makh=null;
    var $ngaydat=null;
    var $tongtien=null;
    var $mahh=null;
    public function __construct()
    {
        
    }
    // viết phương thức insert vào hoadon1
    // tại sao ko nhận là mã số hd vì mã số tự tăng ko cần truyền,ngày ko cần truyền vì nó lấy ngày 
    // hiện tại, tổng tiền chưa truyền vào đc vì tổng tiền nó tính là dựa trên thành tiền trong bảng chi tiết

    public function insertOrder($makh)//insertOrder
    {
        
        $date=new DateTime("now");
        $ngay=$date->format("Y-m-d");
        $query="insert into hoadon1(masohd,makh,ngaydat,tongtien)values(NULL,$makh,'$ngay',0)";
        // ai thực hiện câu truy vấn này? exec, prepare
       
        $db=new connect();
        $db->exec($query);
        // đã chèn vào đc bảng hóa đơn
        // sau khi chèn xong phải lấy được mã số hd để chèn vào bảng chi tiest hóa đơn
        $select="select masohd from hoadon1 order by masohd desc limit 1";//26
        // câu truy vấn này ai thực thi? query, prepare
        $result=$db->getInstance($select);//$result[26]
        return  $result[0];// masohd
    }
    // dùng dạng tiêu chuẩn(các em về làm dạng prepare)
    public function insertOrderDetail($masohd,$mahh,$soluong,$mausac,$size,$thanhtien)
    {
        $query="insert into cthoadon1(masohd,mahh,soluongmua,mausac,size,thanhtien,tinhtrang) values($masohd,$mahh,$soluong,'$mausac',$size,$thanhtien,0)";
        $db=new connect();
        $db->exec($query);
    }
    // dạng tiêu chuẩn
    function updateOrderTotal($masohd,$total)
    {
        $query="update hoadon1 set tongtien=$total where masohd=$masohd";
        // ai thực thi câu truy vấn trên? exec, prepare
        $db=new connect();
        $db->exec($query);
    }
    // lấy thông tin của 1 hóa đơn ra
    function getOrder($sohdid)
    {
        $select="select b.masohd,a.tenkh,b.ngaydat,a.diachi,a.sodienthoai from khachhang1 a 
        inner join hoadon1 b on a.makh=b.makh where masohd=$sohdid";
       
        $db=new connect();
        $result=$db->getInstance($select);
        return $result;
    }
    // lấy thông tin của tất cả sản phẩm trên hóa đơn
    function getOrderDetail($sohdid)
    {
        $select="select a.tenhh,a.dongia,b.mausac,b.size,b.soluongmua,b.thanhtien from hanghoa a 
        inner join cthoadon1 b on a.mahh=b.mahh where masohd=$sohdid";
      
        $db=new connect();
        $result=$db->getList($select);
        return $result;
    }
}
?>