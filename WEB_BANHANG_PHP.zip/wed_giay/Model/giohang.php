<?php
//ko cần tạo lớp 
function add_item($mah,$quantity,$mycolor,$size) 
{
    //thiếu hình tên , đơn giá ,nhưng do lấy đc mã hàng nào r , từ mã hàng truy suất 
    //hình tên đơn giá 
    $pros=new HangHoa();
    $pro=$pros->getListDetail($mah);
    //kiểm tra xem sản phẩm tồn tại chauw ,nếu r thì cập nhạt lại 
    if(isset($_SESSION['cart'][$mah]))
    {
        $quantity+=$_SESSION['cart'][$mah]['qty'];
        update_item($mah,$quantity);
        return;
    }
    ////
    //$pros là lấy đc 1 thông tin sản phảm cần mua 
    $cost=$pro['dongia'];//dongia tên cột trong database 
    $ten=$pro['tenhh'];
    $hinh=$pro['hinh'];
    $total=$cost*$quantity;
    //tạo thôn tin của 1 sản phẩm , 1 sản phẩm chứa nhiêu thuộc tính 
    //muốn lưu phải tạo mảng 
    $item=array(
        'mahh'=>$mah,//key=>value
        'hinh'=>$hinh,
        'name'=>$ten,
        'mau'=>$mycolor,
        'size'=>$size,
        'cost'=>$cost,
        'qty'=>$quantity,
        'total'=>$total,
    );
    $_SESSION['cart'][$mah]=$item;
 /// phuong thức tổn tiền 
}
function get_subtotal()
 {
      $subtotal=0 ;
     foreach($_SESSION['cart'] as $item)
      {
        $subtotal+=$item['total'];
     }
     $subtotal=number_format($subtotal,);
     return $subtotal;
 }
 //trường hợp chọn thôn tin thêm 1 sp mà nó trùng 
 //tức là sản phaamr đó đã có r 
 function update_item($mahh,$quantity)
 {
     if($quantity<=0)//người chọn âm nhỏ hơn 0 là xóa luôn
     {
        unset($_SESSION['cart'][$mahh]);
     }
     else
     {
      $_SESSION['cart'][$mahh]['qty']=$quantity;
     // tinh lai thanh tien 
      $totalnew=$_SESSION['cart'][$mahh]['qty']*$_SESSION['cart'][$mahh]['cost'];
      $_SESSION['cart'][$mahh]['total']=$totalnew;
     }
} 
?>