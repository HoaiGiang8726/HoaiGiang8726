<?php
class HangHoa{
    // thuộc tính(tức là các cột trong bảng dữ liệu)
    var $mahh=null;
    var $tenhh=null;
    // tại sao khởi gán bằng 0 vì kiểu của nó là kiểu số
    var $dongia=0;
    var $giamgia=0;
    var $hinh="imagetourdien/";
    var $nhom=0;
    var $maloai=null;
    // đặc biệt là kiểu bit(chỉ có 2 giá trị 0 và 1) cũng là số nên khởi tạo=0
    var $dacbiet=0;
    var $soluotxem=0;
    var $ngaylap=null;
    var $mota=null;
    var $solt=0;
    var $mausac=null;
    var $size=0;
    // hàm tạo
    public function __construct(){
        if(func_num_args()==14)
        {
            $this->mahh=func_get_arg(0);
            $this->tenhh=func_get_arg(1);
            $this->dongia=func_get_arg(2);
            $this->giamgia=func_get_arg(3);
            $this->hinh=func_get_arg(4);
            $this->nhom=func_get_arg(5);
            $this->maloai=func_get_arg(6);
            $this->dacbiet=func_get_arg(7);
            $this->soluotxem=func_get_arg(8);
            $this->ngaylap=func_get_arg(9);
            $this->mota=func_get_arg(10);
            $this->solt=func_get_arg(11);
            $this->mausac=func_get_arg(12);
            $this->size=func_get_arg(13);
           
        }
    }
    // phương thức của 1 bảng thường là những câu truy vấn (select, insert,update,delect)
   // dạng tiêu chuẩn
    function getListHangHoaNew()
    {
        // đầu tiên phải có câu truy vấn
        $select="select * from hanghoa order by mahh DESC limit 12";
        // ai thực thi câu truy vấn này là query thực hiện
        $db=new connect();
        // vì getList($select) nó return về 12 sản phẩm thì cần có
        // 1 biến lưu trữ 12 sản phẩm đó, biến đó là $result
        $result=$db->getList($select);
        return $result;
    }
    // getListHanghoaNew nó chứa 12 sản phẩm lấy từ databse về
    // phương thức hàng hóa sale
    function getListHangHoaSale()
    {
        // đầu tiên phải có câu truy vấn
        $select="select * from hanghoa where giamgia>0 limit 8";
        // ai thực thi câu truy vấn này là query thực hiện
        $db=new connect();
        // vì getList($select) nó return về 12 sản phẩm thì cần có
        // 1 biến lưu trữ 12 sản phẩm đó, biến đó là $result
        $result=$db->getList($select);
        return $result;
    }
    function getListHangHoaAll()
    {
        $select="select * from hanghoa";
        // ai thực thi câu truy vấn này là query thực hiện
        $db=new connect();
        // vì getList($select) nó return về 12 sản phẩm thì cần có
        // 1 biến lưu trữ 12 sản phẩm đó, biến đó là $result
        $result=$db->getList($select);
        return $result;
    }
    function getListHangHoaSaleAll()
    {
        // đầu tiên phải có câu truy vấn
        $select="select * from hanghoa where giamgia>0";
        // ai thực thi câu truy vấn này là query thực hiện
        $db=new connect();
        // vì getList($select) nó return về 12 sản phẩm thì cần có
        // 1 biến lưu trữ 12 sản phẩm đó, biến đó là $result
        $result=$db->getList($select);
        return $result;
    }
    function getListDetail($id)
    {
        $select ="select * from hanghoa where mahh=$id";
        // mỗi id chỉ trả về đúng 1 row
        $db=new connect();
        $result=$db->getInstance($select);
        return $result;
    }
    // getListDetail lấy đc thông tin của 1 sản phẩm từ database về
    function getListDetailNhom($nhom)
    {
        $select ="select * from hanghoa where nhom=$nhom";
        // mỗi id chỉ trả về đúng 1 row
        $db=new connect();
        $result=$db->getList($select);
        return $result;
    }

//dùng prepare
    // function getListDetailNhomSize($nhom)
    // {
    //     $select ="select distinct(size) from hanghoa where nhom=:nhom";
    //     //câu truy vấn lag prepare
    //     $db=new connect();
    //     $stm=$db->execP($select);
    //     $stm->bindParam(':nhom',$nhom);
    //     $stm->execute();
    //     return $stm;
    // }
    //dùng getlist
    function getListDetailNhomSize($nhom)
    {
        $select ="select distinct(size) from hanghoa where nhom=$nhom";
        $db=new connect();
        $result=$db->getList($select);
        return $result;
    }
    //dạng 1  cơ bản dùng quẻy
    // function getSearch($search)
    // {
    //     $select="select * from hanghoa where tenhh like '%$search%'";
    //     $db=new connect();
    //     $result=$db->getList($select);
    //     return $result;
    // }
    //dạng 2 prepare
    function getSearch($search)
    {
        $select="select * from hanghoa where tenhh like :tenhh";
        $db=new connect();
        $stm=$db->execP($select);
        //rằng buộc thma số hoặc giá trị 
        //bindvalue là nó truyền vào 1 giá trị 
        $stm->bindvalue(':tenhh',"%".$search."%");
        $stm->execute();
        return $stm;
    }///câu này trả về giá trị lấy từ database về 
}
?>